rag model

